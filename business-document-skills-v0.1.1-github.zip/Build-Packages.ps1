﻿param([string]$OutputDirectory = '')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$kitRoot = [IO.Path]::GetFullPath($PSScriptRoot)
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $kitRoot 'packages' }
$packageRoot = [IO.Path]::GetFullPath($OutputDirectory)
if (-not $packageRoot.StartsWith($kitRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Output must stay inside this kit.' }
$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
function Read-Text([string]$Path) { return [IO.File]::ReadAllText($Path, $utf8).Replace("`r`n", "`n") }
function Write-Text([string]$Path, [string]$Content) {
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Path)) | Out-Null
    [IO.File]::WriteAllText($Path, $Content.Replace("`r`n", "`n"), $utf8)
}
function Get-TextHash([string]$Text) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($utf8.GetBytes($Text)))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
$sourceRoot = Join-Path $kitRoot 'source'
$core = Read-Text (Join-Path $sourceRoot 'common/editing-core.md')
$items = @(
    @{ Name = 'business-ppt-editor'; Title = '商业PPT工作台'; Workflow = 'ppt-workflow.md'; Description = '制作和修改商业PPT，整合资料研究、业务分析、大纲、逐页文案、图表表达、去AI味与交付审核；保留原页、数据和可编辑对象。适用于汽车、金融、市场研究及BP，不处理纯Word或邮件写作。'; English = 'Research, draft and refine business presentations while preserving evidence, existing slides and editable objects.' },
    @{ Name = 'business-word-editor'; Title = '商业Word与文字工作台'; Workflow = 'word-workflow.md'; Description = '起草和修改商业Word文档、报告、方案、纪要、BP正文、商务邮件和工作消息，整合资料研究、分析、写作、精简、去AI味、双语校准及排版审核；不处理PPT页面制作。'; English = 'Research, draft and edit business documents, reports, meeting notes and correspondence with evidence and concise professional language.' }
)
$results = New-Object 'System.Collections.Generic.List[object]'
foreach ($item in $items) {
    $body = (Read-Text (Join-Path $sourceRoot $item.Workflow)).TrimEnd() + "`n`n" + $core.TrimEnd() + "`n"
    foreach ($hostName in @('codex', 'workbuddy')) {
        $folder = Join-Path (Join-Path $packageRoot $hostName) $item.Name
        if (Test-Path -LiteralPath $folder) { throw "Build target already exists; choose a fresh OutputDirectory: $folder" }
        [IO.Directory]::CreateDirectory($folder) | Out-Null
        if ($hostName -eq 'codex') {
            $header = "---`nname: $($item.Name)`ndescription: $($item.Description)`nmetadata:`n  version: `"0.1.1`"`n---`n`n"
        } else {
            $header = "---`nname: $($item.Name)`ndisplay_name: $($item.Title)`ndescription: $($item.Description)`ndescription_zh: $($item.Description)`ndescription_en: $($item.English)`nversion: `"0.1.1`"`nauthor: Local Custom`n---`n`n"
        }
        Write-Text (Join-Path $folder 'SKILL.md') ($header + $body)
        foreach ($reference in Get-ChildItem -LiteralPath (Join-Path $sourceRoot 'common/references') -File) {
            Write-Text (Join-Path $folder ('references/' + $reference.Name)) (Read-Text $reference.FullName)
        }
        # WorkBuddy's documented reference syntax is also included; files are identical.
        if ($hostName -eq 'workbuddy') {
            # Relative Markdown links already identify each resource; no host tool names are embedded.
            $referenceIndex = "`n## WorkBuddy 子资源索引`n`n按任务需要读取，文件内容与上文链接一致：`n"
            foreach ($reference in Get-ChildItem -LiteralPath (Join-Path $folder 'references') -File) {
                $referenceIndex += "- @references/$($reference.Name)`n"
            }
            Write-Text (Join-Path $folder 'SKILL.md') ($header + $body + $referenceIndex)
        }
        $skillText = Read-Text (Join-Path $folder 'SKILL.md')
        if ($skillText.Contains([char]0xFFFD)) { throw 'Invalid replacement character.' }
        if ($item.Name.Length -ge 64 -or $item.Name -notmatch '^[a-z0-9]+(-[a-z0-9]+)*$') { throw 'Invalid skill name.' }
        if ($item.Description.Length -gt 1024) { throw 'Description too long.' }
        $front = [regex]::Match($skillText, '(?s)\A---\n(.+?)\n---\n')
        if (-not $front.Success) { throw 'Invalid frontmatter boundary.' }
        $keys = @([regex]::Matches($front.Groups[1].Value, '(?m)^([a-z_-]+):').ForEach({ $_.Groups[1].Value }))
        $required = if ($hostName -eq 'codex') { @('name','description') } else { @('name','description','description_zh','description_en','version','author') }
        foreach ($key in $required) { if ($keys -notcontains $key) { throw "Missing $key" } }
        if ($hostName -eq 'codex' -and @($keys | Where-Object { $_ -notin @('name','description','metadata') }).Count) { throw 'Unsupported Codex keys.' }
        foreach ($link in [regex]::Matches($skillText, '\]\((references/[^)]+)\)')) {
            if (-not (Test-Path -LiteralPath (Join-Path $folder $link.Groups[1].Value))) { throw "Broken link $link" }
        }
        $zipPath = Join-Path $packageRoot ($item.Name + '-v0.1.1-' + $hostName + '.zip')
        if (Test-Path -LiteralPath $zipPath) { throw "Archive already exists: $zipPath" }
        $zip = [IO.Compression.ZipFile]::Open($zipPath, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($file in Get-ChildItem -LiteralPath $folder -File -Recurse) {
                $relative = $file.FullName.Substring($folder.Length + 1).Replace('\','/')
                # WorkBuddy upload: SKILL.md at archive root; Codex: one named skill folder.
                $entryName = if ($hostName -eq 'codex') { $item.Name + '/' + $relative } else { $relative }
                [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $entryName, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
            }
        } finally { $zip.Dispose() }
        $verify = [IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            $expectedEntry = if ($hostName -eq 'codex') { $item.Name + '/SKILL.md' } else { 'SKILL.md' }
            if (@($verify.Entries | Where-Object { $_.FullName -eq $expectedEntry }).Count -ne 1) { throw 'Archive entry missing.' }
            $expectedCount = 1 + @(Get-ChildItem -LiteralPath (Join-Path $folder 'references') -File).Count
            if ($verify.Entries.Count -ne $expectedCount) { throw "Unexpected archive file count: $($verify.Entries.Count)" }
            foreach ($entry in $verify.Entries) {
                if ($entry.FullName.Contains('..') -or $entry.FullName.Contains('\') -or $entry.FullName.StartsWith('/')) { throw 'Unsafe archive path.' }
                $reader = New-Object IO.StreamReader($entry.Open(), $utf8)
                try { $actual = $reader.ReadToEnd() } finally { $reader.Dispose() }
                $relativeEntry = if ($hostName -eq 'codex') { $entry.FullName.Substring($item.Name.Length + 1) } else { $entry.FullName }
                if ($actual -cne (Read-Text (Join-Path $folder $relativeEntry))) { throw 'Archive content mismatch.' }
            }
        } finally { $verify.Dispose() }
        $results.Add([pscustomobject]@{ Skill = $item.Name; Host = $hostName; Version = '0.1.1'; Archive = [IO.Path]::GetFileName($zipPath); SHA256 = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant(); SharedBodySHA256 = Get-TextHash $body; Checks = 'PASS: metadata, references, UTF-8, archive entries and content' })
    }
}
foreach ($name in $items.Name) {
    $pair = @($results | Where-Object { $_.Skill -eq $name })
    if ($pair[0].SharedBodySHA256 -cne $pair[1].SharedBodySHA256) { throw 'Cross-host body mismatch.' }
    foreach ($reference in Get-ChildItem -LiteralPath (Join-Path $packageRoot "codex/$name/references") -File) {
        $other = Join-Path $packageRoot "workbuddy/$name/references/$($reference.Name)"
        if ((Get-FileHash -LiteralPath $reference.FullName).Hash -ne (Get-FileHash -LiteralPath $other).Hash) { throw 'Cross-host reference mismatch.' }
    }
}
Write-Text (Join-Path $packageRoot 'manifest.json') ($results | ConvertTo-Json -Depth 4)
$results | Format-Table Skill,Host,Checks -AutoSize
Write-Output 'Build complete. No global skill directories were modified.'
